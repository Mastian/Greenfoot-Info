
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Player extends Actor
{
    public Player()
    {
        setImage("Player.png");
        this.getImage().scale(30,30);
    }
    int cd;
    public void act() 
    {
        cd = cd - 1;
        if (Greenfoot.isKeyDown("d"))
        {
            setLocation(getX() + 2, getY());
        }

        if (Greenfoot.isKeyDown("a"))
        {
            setLocation(getX() - 2, getY());
        }

        if (Greenfoot.isKeyDown("space"))
        {
            if (cd < 0)
            {
                getWorld().addObject(new Geschoss(), getX(), getY());
                cd = 30;
            }
        }
    }    
}
