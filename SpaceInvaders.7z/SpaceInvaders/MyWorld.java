import greenfoot.*;  
import java.util.*;
public class MyWorld extends World
{

    public MyWorld()
    {    
        super(600, 400, 1); 
        this.addObject(new Player(), 300, 350);
        for (int i = 0; i<4; i++)
            {
                for (int i2 = 0; i2 < 12; i2++)
                {
                    this.addObject(new Enemy(), 50*i2 + 25 , 50*i + 25);
                }
            }
            
    }
}
