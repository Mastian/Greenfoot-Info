import greenfoot.*;
import java.util.*;

public class Geschoss extends Actor
{
    public Geschoss()
    {
        setImage("Geschoss.png");
        this.getImage().scale(30,30);
    }
    
    public void act() 
    {
        if ((this.isTouching(Enemy.class)))
        {
            removeTouching(Enemy.class);
            getWorld().removeObject(this);
            return;
        }
        if (isAtEdge())
        {
            getWorld().removeObject(this);
            return;
        }
        setLocation(getX(), getY() - 7);
    }    
}
