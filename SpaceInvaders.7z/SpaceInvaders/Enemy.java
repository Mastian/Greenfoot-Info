import greenfoot.*;
import java.util.*;

public class Enemy extends Actor{

public Enemy(){
    setImage("Enemy.png");
    this.getImage().scale(30,30);

}

    public void act() 
    {
        if (this.isTouching(Player.class))
        {
            getWorld().showText("Game Over", 100, 50);
            Greenfoot.stop();
        }
        if (!(isAtEdge())){
            setLocation(this.getX(), this.getY() + 1);
            return;
        }
        setLocation(this.getX(), 50);
    }    
}
