import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
public class Shot extends Actor
{
    public Shot(){
        getImage().scale(50,50);
        setRotation(90);
    }
    public void act() 
    {
        setLocation(getX(), getY()-1);
       // if(Greenfoot.isAtEdge)
            getWorld().removeObject(this);
    }    
}
