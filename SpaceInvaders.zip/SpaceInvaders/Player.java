import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
public class Player extends Actor
{
    public Player (){
        getImage().scale(80,80);
    }

    public void act() 
    {
        //bewegen
        if(Greenfoot.isKeyDown("left"))
            setLocation(getX()-1, getY());
        if(Greenfoot.isKeyDown("right"))
            setLocation(getX()+1, getY());
        if(Greenfoot.isKeyDown("up"))
            getWorld().addObject(new Shot(), getX(), getY());
    }    
}
